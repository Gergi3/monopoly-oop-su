#pragma once

enum class MovePositionType
{
	Forward,
	Back,
	Goto
};