#include "InsufficientBalanceException.h"

const char* InsufficientBalanceException::what() const noexcept
{
	return "";
}
