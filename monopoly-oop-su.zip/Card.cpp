#include "Card.h"

Card::Card(const String& name) : name(name)
{}