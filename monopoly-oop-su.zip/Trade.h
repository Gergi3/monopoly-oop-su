#pragma once
class Trade
{};

