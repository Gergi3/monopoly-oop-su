#pragma once

enum class Key
{
	UP = 0x26,
	DOWN = 0x28,
	ENTER = 0x0D,
	ESCAPE = 0x1B,
};