#pragma once
class Monopoly
{};

