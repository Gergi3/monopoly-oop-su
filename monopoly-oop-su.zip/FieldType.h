#pragma once

enum class FieldType
{
	Property = 0,
};