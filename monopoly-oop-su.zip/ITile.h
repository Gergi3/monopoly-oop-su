#pragma once

class ITile
{

};